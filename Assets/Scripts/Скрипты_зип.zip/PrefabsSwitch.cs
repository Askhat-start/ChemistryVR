using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrefabsSwitch : MonoBehaviour
{
    public GameObject newScenePrefab;
    public GameObject termitScenePrefab;
    public GameObject malachitScenePrefab;
    public GameObject completeXrOrigin;
    //public GameObject quad;
    
    //private void UnLoadScreen(){
    //   quad.SetActive(false);
    //}

    //private void LoadScreen(){
    //    quad.SetActive(true);
    //    Invoke("UnLoadScreen", 2.5f);
    //}
    
    public void GoToTermit(){
        newScenePrefab.SetActive(false);
        termitScenePrefab.SetActive(true);
        completeXrOrigin.transform.position = new Vector3(0.277f, 0.487f, -0.623f);
        //LoadScreen();
    }

    public void GoToMalachit(){
        newScenePrefab.SetActive(false);
        malachitScenePrefab.SetActive(true);
        completeXrOrigin.transform.position = new Vector3(-0.049f, 0.38f, -2.228f);
        //LoadScreen();
    }
}
