using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Experiments : MonoBehaviour
{
    public GameObject malachitScreen;
    public GameObject termitScreen;
    public GameObject O2Screen;

    public void ToTermit(){
        malachitScreen.SetActive(false);
        termitScreen.SetActive(true);
    }

    public void ToO2(){
        termitScreen.SetActive(false);
        O2Screen.SetActive(true);
    }

    public void ToMalachit(){
        O2Screen.SetActive(false);
        malachitScreen.SetActive(true);
    }
}
